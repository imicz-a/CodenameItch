
print("hello, world")